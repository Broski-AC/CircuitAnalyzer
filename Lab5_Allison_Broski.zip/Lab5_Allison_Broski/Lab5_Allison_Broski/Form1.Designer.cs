﻿namespace Lab5_Allison_Broski
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picParallel = new System.Windows.Forms.PictureBox();
            this.picSeries = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkRemove = new System.Windows.Forms.CheckBox();
            this.lblR3Name = new System.Windows.Forms.Label();
            this.lblV3Name = new System.Windows.Forms.Label();
            this.lblV3 = new System.Windows.Forms.Label();
            this.lblVoltage = new System.Windows.Forms.Label();
            this.lblVoltageName = new System.Windows.Forms.Label();
            this.lblCurrent = new System.Windows.Forms.Label();
            this.lblCurrentName = new System.Windows.Forms.Label();
            this.lblR1Name = new System.Windows.Forms.Label();
            this.lblV1Name = new System.Windows.Forms.Label();
            this.lblV1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblR2Name = new System.Windows.Forms.Label();
            this.lblV2 = new System.Windows.Forms.Label();
            this.txtR1 = new System.Windows.Forms.TextBox();
            this.txtR3 = new System.Windows.Forms.TextBox();
            this.txtR2 = new System.Windows.Forms.TextBox();
            this.trkVoltage = new System.Windows.Forms.TrackBar();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picParallel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSeries)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkVoltage)).BeginInit();
            this.SuspendLayout();
            // 
            // picParallel
            // 
            this.picParallel.BackgroundImage = global::Lab5_Allison_Broski.Properties.Resources._141Lab5_Circuit1;
            this.picParallel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picParallel.Location = new System.Drawing.Point(127, 70);
            this.picParallel.Name = "picParallel";
            this.picParallel.Size = new System.Drawing.Size(560, 225);
            this.picParallel.TabIndex = 1;
            this.picParallel.TabStop = false;
            // 
            // picSeries
            // 
            this.picSeries.BackgroundImage = global::Lab5_Allison_Broski.Properties.Resources._141Lab5_Circuit2;
            this.picSeries.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picSeries.Location = new System.Drawing.Point(127, 70);
            this.picSeries.Name = "picSeries";
            this.picSeries.Size = new System.Drawing.Size(560, 224);
            this.picSeries.TabIndex = 0;
            this.picSeries.TabStop = false;
            this.picSeries.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(140, 281);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 2;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // chkRemove
            // 
            this.chkRemove.Location = new System.Drawing.Point(185, 300);
            this.chkRemove.Name = "chkRemove";
            this.chkRemove.Size = new System.Drawing.Size(162, 34);
            this.chkRemove.TabIndex = 3;
            this.chkRemove.Text = "Remove R3 from Circuit";
            this.chkRemove.UseVisualStyleBackColor = true;
            this.chkRemove.CheckedChanged += new System.EventHandler(this.chkRemove_CheckedChanged);
            // 
            // lblR3Name
            // 
            this.lblR3Name.BackColor = System.Drawing.Color.GreenYellow;
            this.lblR3Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblR3Name.Location = new System.Drawing.Point(291, 151);
            this.lblR3Name.Name = "lblR3Name";
            this.lblR3Name.Size = new System.Drawing.Size(44, 27);
            this.lblR3Name.TabIndex = 4;
            this.lblR3Name.Text = "R3";
            this.lblR3Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblV3Name
            // 
            this.lblV3Name.BackColor = System.Drawing.Color.PeachPuff;
            this.lblV3Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblV3Name.Location = new System.Drawing.Point(292, 184);
            this.lblV3Name.Name = "lblV3Name";
            this.lblV3Name.Size = new System.Drawing.Size(43, 27);
            this.lblV3Name.TabIndex = 5;
            this.lblV3Name.Text = "V3";
            this.lblV3Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblV3
            // 
            this.lblV3.BackColor = System.Drawing.Color.PeachPuff;
            this.lblV3.Location = new System.Drawing.Point(341, 184);
            this.lblV3.Name = "lblV3";
            this.lblV3.Size = new System.Drawing.Size(59, 27);
            this.lblV3.TabIndex = 10;
            // 
            // lblVoltage
            // 
            this.lblVoltage.BackColor = System.Drawing.Color.PaleVioletRed;
            this.lblVoltage.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVoltage.Location = new System.Drawing.Point(65, 223);
            this.lblVoltage.Name = "lblVoltage";
            this.lblVoltage.Size = new System.Drawing.Size(56, 36);
            this.lblVoltage.TabIndex = 14;
            this.lblVoltage.Text = "4";
            this.lblVoltage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVoltageName
            // 
            this.lblVoltageName.BackColor = System.Drawing.Color.PaleVioletRed;
            this.lblVoltageName.Location = new System.Drawing.Point(65, 175);
            this.lblVoltageName.Name = "lblVoltageName";
            this.lblVoltageName.Size = new System.Drawing.Size(56, 36);
            this.lblVoltageName.TabIndex = 15;
            this.lblVoltageName.Text = "Voltage Source";
            this.lblVoltageName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblVoltageName.Click += new System.EventHandler(this.label13_Click);
            // 
            // lblCurrent
            // 
            this.lblCurrent.BackColor = System.Drawing.Color.SandyBrown;
            this.lblCurrent.Location = new System.Drawing.Point(140, 25);
            this.lblCurrent.Name = "lblCurrent";
            this.lblCurrent.Size = new System.Drawing.Size(85, 27);
            this.lblCurrent.TabIndex = 16;
            // 
            // lblCurrentName
            // 
            this.lblCurrentName.AutoSize = true;
            this.lblCurrentName.Location = new System.Drawing.Point(140, 9);
            this.lblCurrentName.Name = "lblCurrentName";
            this.lblCurrentName.Size = new System.Drawing.Size(71, 13);
            this.lblCurrentName.TabIndex = 17;
            this.lblCurrentName.Text = "Current (I) --->";
            // 
            // lblR1Name
            // 
            this.lblR1Name.BackColor = System.Drawing.Color.GreenYellow;
            this.lblR1Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblR1Name.Location = new System.Drawing.Point(418, 9);
            this.lblR1Name.Name = "lblR1Name";
            this.lblR1Name.Size = new System.Drawing.Size(44, 27);
            this.lblR1Name.TabIndex = 18;
            this.lblR1Name.Text = "R1";
            this.lblR1Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblV1Name
            // 
            this.lblV1Name.BackColor = System.Drawing.Color.PeachPuff;
            this.lblV1Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblV1Name.Location = new System.Drawing.Point(418, 36);
            this.lblV1Name.Name = "lblV1Name";
            this.lblV1Name.Size = new System.Drawing.Size(44, 27);
            this.lblV1Name.TabIndex = 19;
            this.lblV1Name.Text = "V1";
            this.lblV1Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblV1
            // 
            this.lblV1.BackColor = System.Drawing.Color.PeachPuff;
            this.lblV1.Location = new System.Drawing.Point(468, 36);
            this.lblV1.Name = "lblV1";
            this.lblV1.Size = new System.Drawing.Size(59, 27);
            this.lblV1.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.PeachPuff;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(693, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 27);
            this.label2.TabIndex = 21;
            this.label2.Text = "V2";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblR2Name
            // 
            this.lblR2Name.BackColor = System.Drawing.Color.GreenYellow;
            this.lblR2Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblR2Name.Location = new System.Drawing.Point(693, 151);
            this.lblR2Name.Name = "lblR2Name";
            this.lblR2Name.Size = new System.Drawing.Size(44, 27);
            this.lblR2Name.TabIndex = 22;
            this.lblR2Name.Text = "R2";
            this.lblR2Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblV2
            // 
            this.lblV2.BackColor = System.Drawing.Color.PeachPuff;
            this.lblV2.Location = new System.Drawing.Point(743, 184);
            this.lblV2.Name = "lblV2";
            this.lblV2.Size = new System.Drawing.Size(59, 27);
            this.lblV2.TabIndex = 23;
            // 
            // txtR1
            // 
            this.txtR1.Location = new System.Drawing.Point(468, 13);
            this.txtR1.Name = "txtR1";
            this.txtR1.Size = new System.Drawing.Size(59, 20);
            this.txtR1.TabIndex = 24;
            this.txtR1.Text = "100";
            this.txtR1.TextChanged += new System.EventHandler(this.txtR1_TextChanged);
            // 
            // txtR3
            // 
            this.txtR3.Location = new System.Drawing.Point(341, 158);
            this.txtR3.Name = "txtR3";
            this.txtR3.Size = new System.Drawing.Size(59, 20);
            this.txtR3.TabIndex = 25;
            this.txtR3.Text = "150";
            this.txtR3.TextChanged += new System.EventHandler(this.txtR3_TextChanged);
            // 
            // txtR2
            // 
            this.txtR2.Location = new System.Drawing.Point(743, 158);
            this.txtR2.Name = "txtR2";
            this.txtR2.Size = new System.Drawing.Size(59, 20);
            this.txtR2.TabIndex = 26;
            this.txtR2.Text = "150";
            this.txtR2.TextChanged += new System.EventHandler(this.txtR2_TextChanged);
            // 
            // trkVoltage
            // 
            this.trkVoltage.AutoSize = false;
            this.trkVoltage.BackColor = System.Drawing.Color.PaleVioletRed;
            this.trkVoltage.Location = new System.Drawing.Point(8, 70);
            this.trkVoltage.Name = "trkVoltage";
            this.trkVoltage.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trkVoltage.Size = new System.Drawing.Size(51, 224);
            this.trkVoltage.TabIndex = 27;
            this.trkVoltage.Value = 4;
            this.trkVoltage.Scroll += new System.EventHandler(this.trkVoltage_Scroll);
            // 
            // btnCalculate
            // 
            this.btnCalculate.BackColor = System.Drawing.Color.MediumTurquoise;
            this.btnCalculate.Location = new System.Drawing.Point(353, 311);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(334, 35);
            this.btnCalculate.TabIndex = 28;
            this.btnCalculate.Text = "Calculate the Values of the Circuit Components";
            this.btnCalculate.UseVisualStyleBackColor = false;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.MediumTurquoise;
            this.btnExit.Location = new System.Drawing.Point(709, 13);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(107, 39);
            this.btnExit.TabIndex = 29;
            this.btnExit.Text = "Exit Program";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.MediumTurquoise;
            this.btnReset.Location = new System.Drawing.Point(709, 58);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(107, 36);
            this.btnReset.TabIndex = 30;
            this.btnReset.Text = "Reset Circuit";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(828, 358);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.trkVoltage);
            this.Controls.Add(this.txtR2);
            this.Controls.Add(this.txtR3);
            this.Controls.Add(this.txtR1);
            this.Controls.Add(this.lblV2);
            this.Controls.Add(this.lblR2Name);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblV1);
            this.Controls.Add(this.lblV1Name);
            this.Controls.Add(this.lblR1Name);
            this.Controls.Add(this.lblCurrentName);
            this.Controls.Add(this.lblCurrent);
            this.Controls.Add(this.lblVoltageName);
            this.Controls.Add(this.lblVoltage);
            this.Controls.Add(this.lblV3);
            this.Controls.Add(this.lblV3Name);
            this.Controls.Add(this.lblR3Name);
            this.Controls.Add(this.chkRemove);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picParallel);
            this.Controls.Add(this.picSeries);
            this.Name = "frmMain";
            this.Text = "Resistance, Voltage, Current";
            ((System.ComponentModel.ISupportInitialize)(this.picParallel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSeries)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkVoltage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picSeries;
        private System.Windows.Forms.PictureBox picParallel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkRemove;
        private System.Windows.Forms.Label lblR3Name;
        private System.Windows.Forms.Label lblV3Name;
        private System.Windows.Forms.Label lblV3;
        private System.Windows.Forms.Label lblVoltage;
        private System.Windows.Forms.Label lblVoltageName;
        private System.Windows.Forms.Label lblCurrent;
        private System.Windows.Forms.Label lblCurrentName;
        private System.Windows.Forms.Label lblR1Name;
        private System.Windows.Forms.Label lblV1Name;
        private System.Windows.Forms.Label lblV1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblR2Name;
        private System.Windows.Forms.Label lblV2;
        private System.Windows.Forms.TextBox txtR1;
        private System.Windows.Forms.TextBox txtR3;
        private System.Windows.Forms.TextBox txtR2;
        private System.Windows.Forms.TrackBar trkVoltage;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReset;
    }
}

